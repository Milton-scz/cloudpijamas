<script setup>
import mxupImage from '@/Pages/LandingPage/images/portada.webp'
</script>

<template>
   <div class="contenido-principal mt-16">
      <img

        :src="mxupImage"
        alt=""
      />

</div>
</template>
