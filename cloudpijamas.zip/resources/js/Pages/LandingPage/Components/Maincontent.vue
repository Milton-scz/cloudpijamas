<!-- resources/js/components/MainContent.vue -->
<template>
    <div class="main-content">
      <div class="container">
        <h1 class="title">Bienvenido a Pijama Cloud</h1>
        <p class="description">
          En Pijama Cloud nos especializamos en ofrecerte las pijamas más cómodas y modernas para todas las edades.
          Nuestro objetivo es que disfrutes de noches tranquilas y con estilo. Descubre nuestra amplia variedad de pijamas
          hechas con materiales suaves y de alta calidad. ¡Te aseguramos que te enamorarás de nuestras colecciones!
        </p>
        <!-- Puedes agregar más secciones o componentes aquí -->
      </div>
    </div>
  </template>


  <script setup>

  </script>

  <style scoped>
  .main-content {
    background-color: #f9f9f9;
    padding: 50px 0;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 15px;
  }

  .title {
    font-size: 2.5rem;
    color: #333;
    text-align: center;
    margin-bottom: 20px;
  }

  .description {
    font-size: 1.2rem;
    color: #666;
    text-align: center;
  }
  </style>
